"""FlowSwitch Windows GUI launcher. Run on Windows with Python 3.11+ and tkinter."""
import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path

try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    DND_AVAILABLE = True
except ImportError:
    DND_FILES = None
    TkinterDnD = None
    DND_AVAILABLE = False

from controller import FlowSwitchController, PORT


class WindowsApp:
    def __init__(self, root):
        self.root = root
        self.root.title("FlowSwitch")
        self.root.geometry("460x760")
        self.root.minsize(420, 700)
        self.dark_mode = tk.BooleanVar(value=True)
        self.messages = queue.Queue()
        self.controller = None
        self.worker = None
        self.download_dir = str(Path.home() / "Downloads")
        self._configure_style()

        outer = ttk.Frame(root, style="App.TFrame", padding=(28, 18, 28, 20))
        outer.pack(fill="both", expand=True)
        top = ttk.Frame(outer, style="App.TFrame")
        top.pack(fill="x")
        self.connection_badge = ttk.Label(top, text="●  DISCONNECTED", style="Disconnected.TLabel")
        self.connection_badge.pack(side="left")
        self.theme_button = ttk.Button(top, text="☼", command=self.toggle_theme, style="Theme.TButton")
        self.theme_button.pack(side="right")

        ttk.Label(outer, text="FlowSwitch", style="Title.TLabel", anchor="center").pack(fill="x", pady=(2, 0))
        ttk.Label(outer, text="Windows", style="Platform.TLabel", anchor="center").pack(fill="x", pady=(0, 4))
        self.monitor = tk.Canvas(outer, height=130, highlightthickness=0, bd=0)
        self.monitor.pack(fill="x", pady=(0, 22))
        self._draw_monitor()

        ttk.Label(outer, text="Mac IP Address", style="Field.TLabel").pack(anchor="center", padx=18)
        self.host = ttk.Entry(outer)
        self.host.insert(0, "192.168.1.")
        self.host.pack(fill="x", padx=18, pady=(5, 12), ipady=4)
        ttk.Label(outer, text="Custom Connection Token", style="Field.TLabel").pack(anchor="center", padx=18)
        self.token = ttk.Entry(outer, show="•")
        self.token.pack(fill="x", padx=18, pady=(5, 16), ipady=4)

        buttons = ttk.Frame(outer, style="App.TFrame")
        buttons.pack(pady=(0, 18))
        self.connect_button = ttk.Button(buttons, text="Connect", command=self.connect, style="Accent.TButton")
        self.connect_button.pack(side="left", padx=5)
        self.stop_button = ttk.Button(buttons, text="Disconnect", command=self.disconnect, style="Danger.TButton", state="disabled")
        self.stop_button.pack(side="left", padx=5)

        ttk.Label(outer, text="Incoming Files Save To:", style="Field.TLabel").pack(anchor="center", padx=18)
        folder_row = ttk.Frame(outer, style="App.TFrame")
        folder_row.pack(fill="x", padx=18, pady=(5, 12))
        self.download_dir_var = tk.StringVar(value=self.download_dir)
        self.folder_entry = ttk.Entry(folder_row, textvariable=self.download_dir_var)
        self.folder_entry.pack(side="left", fill="x", expand=True, ipady=4)
        ttk.Button(folder_row, text="Browse", command=self.choose_download_dir).pack(side="left", padx=(8, 0))

        file_buttons = ttk.Frame(outer, style="App.TFrame")
        file_buttons.pack(pady=(0, 12))
        ttk.Button(file_buttons, text="Send Files", command=self.send_files).pack(side="left", padx=5)
        self.drop_zone = ttk.Label(outer, text=("Drop files here to send to your Mac" if DND_AVAILABLE else "Use Send Files to choose files"), style="Drop.TLabel", anchor="center", padding=10)
        self.drop_zone.pack(fill="x", pady=(0, 8))
        if DND_AVAILABLE:
            self.drop_zone.drop_target_register(DND_FILES)
            self.drop_zone.dnd_bind("<<Drop>>", self.on_files_dropped)

        self.status = tk.StringVar(value="Ready")
        self.status_label = ttk.Label(outer, textvariable=self.status, style="Status.TLabel", anchor="w", padding=(2, 5))
        self.status_label.pack(fill="x", side="bottom", pady=(4, 0))
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.after(150, self.poll_messages)
        self._animation_phase = 0
        self.root.after(180, self._animate_ui)

    def _draw_monitor(self):
        c = self.colors
        self.monitor.configure(bg=c["bg"])
        self.monitor.delete("all")
        w = max(self.monitor.winfo_width(), 300)
        cx = w / 2
        self.monitor.create_rectangle(cx-80, 5, cx+80, 94, outline=c["monitor"], width=3, fill=c["bg"], tags="monitor")
        self.monitor.create_line(cx, 94, cx, 116, fill=c["monitor"], width=3)
        self.monitor.create_line(cx-33, 117, cx+33, 117, fill=c["monitor"], width=3, capstyle="round")
        self.monitor.tag_raise("monitor")

    def _configure_style(self):
        style = ttk.Style(self.root)
        try: style.theme_use("clam")
        except tk.TclError: pass
        dark = self.dark_mode.get()
        c = ({"bg":"#1F1F1F","card":"#252525","field":"#FFFFFF","text":"#F4F4F4","muted":"#C6C6C6","accent":"#F5F5F7","border":"#555555","drop":"#292929","status":"#1F1F1F","status_text":"#D8D8D8","monitor":"#F4F4F4","button":"#F5F5F7","button_text":"#202020"} if dark else {"bg":"#FFFFFF","card":"#FFFFFF","field":"#FFFFFF","text":"#202020","muted":"#4B4B4B","accent":"#2D2D2D","border":"#D8D8D8","drop":"#F5F5F5","status":"#FFFFFF","status_text":"#444444","monitor":"#222222","button":"#2D2D2D","button_text":"#FFFFFF"})
        self.colors=c; self.root.configure(bg=c["bg"])
        style.configure(".", font=("Segoe UI", 10), background=c["bg"], foreground=c["text"])
        style.configure("App.TFrame", background=c["bg"])
        style.configure("Title.TLabel", font=("Segoe UI", 34, "bold"), background=c["bg"], foreground=c["text"])
        style.configure("Platform.TLabel", font=("Segoe UI", 30, "bold"), background=c["bg"], foreground=c["text"])
        style.configure("Field.TLabel", font=("Segoe UI", 9), background=c["bg"], foreground=c["muted"])
        style.configure("Folder.TLabel", background=c["bg"], foreground=c["muted"])
        style.configure("TEntry", fieldbackground=c["field"], foreground="#202020", insertcolor="#202020", padding=7, bordercolor=c["border"])
        style.configure("TButton", background=c["button"], foreground=c["button_text"], padding=(16,9), bordercolor=c["border"], font=("Segoe UI", 9))
        style.map("TButton", background=[("active", c["border"])])
        style.configure("Accent.TButton", background=c["button"], foreground=c["button_text"], padding=(16,9))
        style.configure("Danger.TButton", background="#F5222D", foreground="#FFFFFF", padding=(16,9))
        style.configure("Theme.TButton", background=c["bg"], foreground=c["text"], padding=(6,3), font=("Segoe UI Symbol", 15))
        style.configure("Drop.TLabel", background=c["drop"], foreground=c["text"], font=("Segoe UI", 9, "bold"))
        style.configure("Status.TLabel", background=c["bg"], foreground=c["status_text"], font=("Segoe UI", 9))
        style.configure("Connected.TLabel", background=c["bg"], foreground="#19A765", font=("Segoe UI", 9))
        style.configure("Disconnected.TLabel", background=c["bg"], foreground="#F04444", font=("Segoe UI", 9))
        if hasattr(self, "monitor"): self._draw_monitor()
        if hasattr(self, "theme_button"): self.theme_button.configure(text="☾" if dark else "☼")

    def _animate_ui(self):
        """Subtle, continuous monitor glow and theme-icon motion."""
        if not self.root.winfo_exists():
            return
        self._animation_phase = (self._animation_phase + 1) % 24
        # A slow breathing outline makes the monitor illustration feel alive.
        try:
            if self.monitor.winfo_exists():
                self.monitor.delete("glow")
                c = self.colors["monitor"]
                # Cycle line width gently instead of flashing colors.
                width = 2 if self._animation_phase < 12 else 3
                w = max(self.monitor.winfo_width(), 300)
                cx = w / 2
                self.monitor.create_rectangle(cx-80, 5, cx+80, 94, outline=c, width=width, fill=self.colors["bg"], tags=("glow",))
                self.monitor.tag_lower("glow")
        except tk.TclError:
            pass
        self.root.after(180, self._animate_ui)

    def toggle_theme(self):
        self.dark_mode.set(not self.dark_mode.get())
        self._configure_style()
        # Small, restrained icon change gives the toggle feedback without distracting animations.
        self.theme_button.configure(text="☾" if self.dark_mode.get() else "☼")

    def connect(self):
        host = self.host.get().strip()
        token = self.token.get()
        if not host:
            messagebox.showerror("Missing IP address", "Enter the Mac's IP address.", parent=self.root)
            return
        if len(token) < 16:
            messagebox.showerror("Token too short", "Use the same token as the Mac receiver (at least 16 characters).", parent=self.root)
            return
        if self.worker and self.worker.is_alive():
            return
        self.connect_button.configure(state="disabled")
        self.stop_button.configure(state="normal")
        self.status.set("Connecting…")
        self.controller = FlowSwitchController(host, PORT, token, status_callback=self.messages.put)
        if getattr(self, "download_dir", None):
            self.controller.file_transfer.set_download_dir(self.download_dir)
        self.worker = threading.Thread(target=self.run_controller, daemon=True)
        self.worker.start()

    def run_controller(self):
        failed = False
        try:
            self.controller.run()
        except Exception as exc:
            failed = True
            self.messages.put(f"Connection stopped: {exc}. Windows input is local.")
        finally:
            if not failed:
                self.messages.put("Disconnected. Windows input is local.")

    def choose_download_dir(self):
        folder = filedialog.askdirectory(title="Choose where incoming files are saved", parent=self.root,
                                         initialdir=self.download_dir if Path(self.download_dir).is_dir() else str(Path.home()))
        if folder:
            self.download_dir = folder
            self.download_dir_var.set(folder)
        else:
            folder = self.download_dir_var.get().strip()
        if folder:
            self.download_dir = folder
            if self.controller:
                self.controller.file_transfer.set_download_dir(folder)
            self.status.set(f"Incoming files will be saved to: {folder}")

    def on_files_dropped(self, event):
        try:
            paths = [str(Path(p)) for p in self.root.tk.splitlist(event.data)]
        except Exception as exc:
            self.status.set(f"Couldn't read dropped files: {exc}")
            return "break"
        if not paths:
            return "break"
        if not self.controller or not self.worker or not self.worker.is_alive():
            self.status.set("Connect to your Mac before dropping files to send.")
            return "break"
        files = [p for p in paths if Path(p).is_file()]
        if not files:
            self.status.set("Drop files, not folders, to transfer them.")
            return "break"
        self.controller.file_transfer.send_files(files)
        self.status.set(f"Queued {len(files)} file(s) for transfer to your Mac…")
        return "copy"

    def send_files(self):
        paths = filedialog.askopenfilenames(title="Choose files to send", parent=self.root)
        if not paths:
            return
        if not self.controller or not self.worker or not self.worker.is_alive():
            messagebox.showwarning("Not connected", "Connect to your Mac before sending files.", parent=self.root)
            return
        self.controller.file_transfer.send_files(paths)

    def disconnect(self):
        if self.controller:
            self.status.set("Disconnecting safely…")
            self.controller.request_stop()

    def poll_messages(self):
        try:
            while True:
                message = str(self.messages.get_nowait())
                low = message.lower()
                if "connected" in low and not any(x in low for x in ("disconnected", "connection lost", "not connected", "receiver stopped")):
                    self.connection_badge.configure(text="●  CONNECTED", style="Connected.TLabel")
                    self.status.set("Connected")
                elif any(x in low for x in ("disconnected", "connection lost", "receiver stopped", "stopped")):
                    self.connection_badge.configure(text="●  DISCONNECTED", style="Disconnected.TLabel")
                    self.status.set("Disconnected")
                elif any(x in low for x in ("queued", "saved", "transfer", "error", "failed", "couldn't", "choose")):
                    self.status.set(message)
        except queue.Empty:
            pass
        if not (self.worker and self.worker.is_alive()):
            self.connect_button.configure(state="normal")
            self.stop_button.configure(state="disabled")
        self.root.after(150, self.poll_messages)

    def close(self):
        if self.controller and self.worker and self.worker.is_alive():
            self.controller.request_stop()
            self.root.after(300, self.finish_close)
        else:
            self.root.destroy()

    def finish_close(self):
        if self.worker and self.worker.is_alive():
            self.root.after(200, self.finish_close)
        else:
            self.root.destroy()


if __name__ == "__main__":
    # tkinterdnd2 bundles a native TkDND extension built for Tcl/Tk 8.x.
    # Some Python builds (notably some Python 3.14 macOS builds) use a newer
    # Tcl/Tk runtime, which can make TkinterDnD.Tk() fail during startup.
    # Fall back to standard Tk so the app and file-picker transfer still work.
    if DND_AVAILABLE:
        try:
            root = TkinterDnD.Tk()
        except Exception as exc:
            DND_AVAILABLE = False
            print(f"FlowSwitch: native drag-and-drop unavailable: {exc}")
            print("Use Python 3.12/3.13 with a compatible Tcl/Tk 8.6 build to enable drag-and-drop.")
            root = tk.Tk()
    else:
        root = tk.Tk()
    WindowsApp(root)
    root.mainloop()
