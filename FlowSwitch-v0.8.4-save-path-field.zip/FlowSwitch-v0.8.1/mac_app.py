"""FlowSwitch Mac GUI receiver. Run on macOS with Python 3.11+, tkinter and pynput."""
import queue
from pathlib import Path
import socket
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    DND_AVAILABLE = True
except ImportError:
    DND_FILES = None
    TkinterDnD = None
    DND_AVAILABLE = False

from receiver import PORT, run_receiver, send_files_to_controller


def local_ip():
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("192.0.2.1", 9))
        address = probe.getsockname()[0]
        if address and not address.startswith("127."):
            return address
    except OSError:
        pass
    finally:
        probe.close()
    try:
        return socket.gethostbyname(socket.gethostname())
    except OSError:
        return "Unavailable — check network settings"


class MacApp:
    def __init__(self, root):
        self.root = root
        self.root.title("FlowSwitch")
        self.root.geometry("460x760")
        self.root.minsize(420, 700)
        self.dark_mode = tk.BooleanVar(value=False)
        self.messages = queue.Queue()
        self.stop_event = None
        self.worker = None
        self._configure_style()

        outer = ttk.Frame(root, style="App.TFrame", padding=(28, 18, 28, 20))
        outer.pack(fill="both", expand=True)
        top = ttk.Frame(outer, style="App.TFrame")
        top.pack(fill="x")
        self.connection_badge = ttk.Label(top, text="●  DISCONNECTED", style="Disconnected.TLabel")
        self.connection_badge.pack(side="left")
        self.theme_button = ttk.Button(top, text="☾", command=self.toggle_theme, style="Theme.TButton")
        self.theme_button.pack(side="right")

        ttk.Label(outer, text="FlowSwitch", style="Title.TLabel", anchor="center").pack(fill="x", pady=(2, 0))
        ttk.Label(outer, text="MacOS", style="Platform.TLabel", anchor="center").pack(fill="x", pady=(0, 4))
        self.monitor = tk.Canvas(outer, height=130, highlightthickness=0, bd=0)
        self.monitor.pack(fill="x", pady=(0, 22))
        self._draw_monitor()

        ttk.Label(outer, text="Mac IP Address", style="Field.TLabel").pack(anchor="center", padx=18)
        iprow = ttk.Frame(outer, style="App.TFrame")
        iprow.pack(fill="x", padx=18, pady=(5, 12))
        self.ip = tk.StringVar(value=local_ip())
        ttk.Entry(iprow, textvariable=self.ip, state="readonly").pack(side="left", fill="x", expand=True)
        ttk.Button(iprow, text="↻", command=lambda: self.ip.set(local_ip())).pack(side="left", padx=(6,0))

        ttk.Label(outer, text="Custom Connection Token", style="Field.TLabel").pack(anchor="center", padx=18)
        self.token = ttk.Entry(outer, show="•")
        self.token.pack(fill="x", padx=18, pady=(5, 16), ipady=4)
        buttons = ttk.Frame(outer, style="App.TFrame")
        buttons.pack(pady=(0, 18))
        self.start_button = ttk.Button(buttons, text="Start Receiver", command=self.start, style="Accent.TButton")
        self.start_button.pack(side="left", padx=5)
        self.stop_button = ttk.Button(buttons, text="Stop Receiver", command=self.stop, style="Danger.TButton", state="disabled")
        self.stop_button.pack(side="left", padx=5)

        ttk.Label(outer, text="Incoming Files Save To:", style="Field.TLabel").pack(anchor="center", padx=18)
        folder_row = ttk.Frame(outer, style="App.TFrame")
        folder_row.pack(fill="x", padx=18, pady=(5, 12))
        self.download_dir = tk.StringVar(value=str(Path.home() / "Downloads"))
        self.folder_entry = ttk.Entry(folder_row, textvariable=self.download_dir)
        self.folder_entry.pack(side="left", fill="x", expand=True, ipady=4)
        ttk.Button(folder_row, text="Browse", command=self.choose_download_dir).pack(side="left", padx=(8,0))
        file_buttons = ttk.Frame(outer, style="App.TFrame")
        file_buttons.pack(pady=(0, 12))
        ttk.Button(file_buttons, text="Send Files", command=self.send_files).pack(side="left", padx=5)
        self.drop_zone = ttk.Label(outer, text=("Drop files here to send to Windows" if DND_AVAILABLE else "Use Send Files to choose files"), style="Drop.TLabel", anchor="center", padding=10)
        self.drop_zone.pack(fill="x", pady=(0, 8))
        if DND_AVAILABLE:
            self.drop_zone.drop_target_register(DND_FILES)
            self.drop_zone.dnd_bind("<<Drop>>", self.on_files_dropped)

        self.status = tk.StringVar(value="Ready")
        ttk.Label(outer, textvariable=self.status, style="Status.TLabel", anchor="w", padding=(2,5)).pack(fill="x", side="bottom", pady=(4,0))
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.after(150, self.poll_messages)
        self._animation_phase = 0
        self.root.after(180, self._animate_ui)

    def _draw_monitor(self):
        c=self.colors; self.monitor.configure(bg=c["bg"]); self.monitor.delete("all")
        cx=max(self.monitor.winfo_width(),300)/2
        self.monitor.create_rectangle(cx-80,5,cx+80,94,outline=c["monitor"],width=3,fill=c["bg"])
        self.monitor.create_line(cx,94,cx,116,fill=c["monitor"],width=3)
        self.monitor.create_line(cx-33,117,cx+33,117,fill=c["monitor"],width=3,capstyle="round")

    def _configure_style(self):
        style=ttk.Style(self.root)
        try: style.theme_use("clam")
        except tk.TclError: pass
        dark=self.dark_mode.get()
        c=({"bg":"#1F1F1F","card":"#252525","field":"#FFFFFF","text":"#F4F4F4","muted":"#C6C6C6","accent":"#F5F5F7","border":"#555555","drop":"#292929","status":"#1F1F1F","status_text":"#D8D8D8","monitor":"#F4F4F4","button":"#F5F5F7","button_text":"#202020"} if dark else {"bg":"#FFFFFF","card":"#FFFFFF","field":"#FFFFFF","text":"#202020","muted":"#4B4B4B","accent":"#2D2D2D","border":"#D8D8D8","drop":"#F5F5F5","status":"#FFFFFF","status_text":"#444444","monitor":"#222222","button":"#2D2D2D","button_text":"#FFFFFF"})
        self.colors=c; self.root.configure(bg=c["bg"])
        style.configure(".",font=("Helvetica Neue",10),background=c["bg"],foreground=c["text"])
        style.configure("App.TFrame",background=c["bg"])
        style.configure("Title.TLabel",font=("Helvetica Neue",34,"bold"),background=c["bg"],foreground=c["text"])
        style.configure("Platform.TLabel",font=("Helvetica Neue",30,"bold"),background=c["bg"],foreground=c["text"])
        style.configure("Field.TLabel",font=("Helvetica Neue",9),background=c["bg"],foreground=c["muted"])
        style.configure("Folder.TLabel",background=c["bg"],foreground=c["muted"])
        style.configure("TEntry",fieldbackground=c["field"],foreground="#202020",insertcolor="#202020",padding=9,bordercolor=c["border"])
        style.configure("TButton",background=c["button"],foreground=c["button_text"],padding=(12,7),bordercolor=c["border"],font=("Helvetica Neue",9))
        style.map("TButton",background=[("active",c["border"])])
        style.configure("Accent.TButton",background=c["button"],foreground=c["button_text"],padding=(16,9))
        style.configure("Danger.TButton",background="#F5222D",foreground="#FFFFFF",padding=(16,9))
        style.configure("Theme.TButton",background=c["bg"],foreground=c["text"],padding=(6,3),font=("Apple Color Emoji",15))
        style.configure("Drop.TLabel",background=c["drop"],foreground=c["text"],font=("Helvetica Neue",9,"bold"))
        style.configure("Status.TLabel",background=c["bg"],foreground=c["status_text"],font=("Helvetica Neue",9))
        style.configure("Connected.TLabel",background=c["bg"],foreground="#19A765",font=("Helvetica Neue",9))
        style.configure("Disconnected.TLabel",background=c["bg"],foreground="#F04444",font=("Helvetica Neue",9))
        if hasattr(self,"monitor"): self._draw_monitor()
        if hasattr(self,"theme_button"): self.theme_button.configure(text="☾" if dark else "☼")

    def _animate_ui(self):
        """Subtle, continuous monitor glow and theme-icon motion."""
        if not self.root.winfo_exists():
            return
        self._animation_phase = (self._animation_phase + 1) % 24
        # A slow breathing outline makes the monitor illustration feel alive.
        try:
            if self.monitor.winfo_exists():
                self.monitor.delete("glow")
                c = self.colors["monitor"]
                # Cycle line width gently instead of flashing colors.
                width = 2 if self._animation_phase < 12 else 3
                w = max(self.monitor.winfo_width(), 300)
                cx = w / 2
                self.monitor.create_rectangle(cx-80, 5, cx+80, 94, outline=c, width=width, fill=self.colors["bg"], tags=("glow",))
                self.monitor.tag_lower("glow")
        except tk.TclError:
            pass
        self.root.after(180, self._animate_ui)

    def toggle_theme(self):
        self.dark_mode.set(not self.dark_mode.get())
        self._configure_style()
        # Small, restrained icon change gives the toggle feedback without distracting animations.
        self.theme_button.configure(text="☾" if self.dark_mode.get() else "☼")

    def start(self):
        token = self.token.get()
        if len(token) < 16:
            messagebox.showerror("Token too short", "Use a token at least 16 characters long.", parent=self.root)
            return
        if self.worker and self.worker.is_alive():
            return
        self.stop_event = threading.Event()
        self.start_button.configure(state="disabled")
        self.stop_button.configure(state="normal")
        self.status.set("Starting receiver…")
        self.worker = threading.Thread(
            target=self.run_server,
            args=(token, self.stop_event, self.download_dir.get().strip()),
            daemon=True,
        )
        self.worker.start()

    def run_server(self, token, stop_event, download_dir):
        try:
            size = (self.root.winfo_screenwidth(), self.root.winfo_screenheight())
            run_receiver(token=token, stop_event=stop_event, status_callback=self.messages.put,
                         screen_size=size, download_dir=download_dir)
        except Exception as exc:
            self.messages.put(f"Receiver error: {exc}")
        finally:
            self.messages.put("Receiver stopped")

    def choose_download_dir(self):
        current = self.download_dir.get().strip()
        folder = filedialog.askdirectory(title="Choose where incoming files are saved", parent=self.root,
                                         initialdir=current if Path(current).is_dir() else str(Path.home()))
        if folder:
            self.download_dir.set(folder)

    def on_files_dropped(self, event):
        try:
            paths = [str(Path(p)) for p in self.root.tk.splitlist(event.data)]
        except Exception as exc:
            self.status.set(f"Couldn't read dropped files: {exc}")
            return "break"
        if not paths:
            return "break"
        files = [p for p in paths if Path(p).is_file()]
        if not files:
            self.status.set("Drop files, not folders, to transfer them.")
            return "break"
        if not send_files_to_controller(files):
            self.status.set("Start the receiver and connect from Windows before sending files.")
            return "break"
        self.status.set(f"Queued {len(files)} file(s) for transfer to Windows…")
        return "copy"

    def send_files(self):
        paths = filedialog.askopenfilenames(title="Choose files to send", parent=self.root)
        if not paths:
            return
        if not send_files_to_controller(paths):
            messagebox.showwarning("Not connected", "Start the receiver and connect from Windows before sending files.", parent=self.root)

    def stop(self):
        if self.stop_event:
            self.status.set("Stopping safely…")
            self.stop_event.set()

    def poll_messages(self):
        try:
            while True:
                message = str(self.messages.get_nowait())
                low = message.lower()
                if "connected" in low and not any(x in low for x in ("disconnected", "connection lost", "not connected", "receiver stopped")):
                    self.connection_badge.configure(text="●  CONNECTED", style="Connected.TLabel")
                    self.status.set("Connected")
                elif any(x in low for x in ("disconnected", "connection lost", "receiver stopped", "stopped")):
                    self.connection_badge.configure(text="●  DISCONNECTED", style="Disconnected.TLabel")
                    self.status.set("Disconnected")
                elif any(x in low for x in ("queued", "saved", "transfer", "error", "failed", "couldn't", "choose")):
                    self.status.set(message)
        except queue.Empty:
            pass
        if not (self.worker and self.worker.is_alive()):
            self.start_button.configure(state="normal")
            self.stop_button.configure(state="disabled")
        self.root.after(150, self.poll_messages)

    def close(self):
        if self.stop_event and self.worker and self.worker.is_alive():
            self.stop_event.set()
            self.root.after(250, self.finish_close)
        else:
            self.root.destroy()

    def finish_close(self):
        if self.worker and self.worker.is_alive():
            self.root.after(200, self.finish_close)
        else:
            self.root.destroy()


if __name__ == "__main__":
    # tkinterdnd2 bundles a native TkDND extension built for Tcl/Tk 8.x.
    # Some Python builds (notably some Python 3.14 macOS builds) use a newer
    # Tcl/Tk runtime, which can make TkinterDnD.Tk() fail during startup.
    # Fall back to standard Tk so the app and file-picker transfer still work.
    if DND_AVAILABLE:
        try:
            root = TkinterDnD.Tk()
        except Exception as exc:
            DND_AVAILABLE = False
            print(f"FlowSwitch: native drag-and-drop unavailable: {exc}")
            print("Use Python 3.12/3.13 with a compatible Tcl/Tk 8.6 build to enable drag-and-drop.")
            root = tk.Tk()
    else:
        root = tk.Tk()
    MacApp(root)
    root.mainloop()
